document.addEventListener('DOMContentLoaded', () => {
    // --- 1. DATABASE: Song Details ---
    // In a real app, this would be fetched from an API.
    const songs = [
        { id: 1, title: 'Lost in the City Lights', artist: 'Cosmo Sheldrake', filePath: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3', imagePath: 'https://placehold.co/300x300/ef4444/ffffff?text=Lost+in+the+City', },
        { id: 2, title: 'Forest Lullaby', artist: 'Lesfm', filePath: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3', imagePath: 'https://placehold.co/300x300/22c55e/ffffff?text=Forest+Lullaby', },
        { id: 3, title: 'Oceanic Drift', artist: 'Purrple Cat', filePath: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3', imagePath: 'https://placehold.co/300x300/3b82f6/ffffff?text=Oceanic+Drift', },
        { id: 4, title: 'Midnight Jazz', artist: 'Coffee Shop Vibes', filePath: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3', imagePath: 'https://placehold.co/300x300/8b5cf6/ffffff?text=Midnight+Jazz', },
        { id: 5, title: 'Sunrise Overdrive', artist: 'NEFFEX', filePath: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-5.mp3', imagePath: 'https://placehold.co/300x300/f97316/ffffff?text=Sunrise+Overdrive', },
        { id: 6, title: 'Desert Winds', artist: 'Coyote Hearing', filePath: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-6.mp3', imagePath: 'https://placehold.co/300x300/eab308/ffffff?text=Desert+Winds', },
        { id: 7, title: 'Retrograde', artist: 'James Blake', filePath: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-7.mp3', imagePath: 'https://placehold.co/300x300/ec4899/ffffff?text=Retrograde', },
        { id: 8, title: 'Quantum Leap', artist: 'Electronica', filePath: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-8.mp3', imagePath: 'https://placehold.co/300x300/14b8a6/ffffff?text=Quantum+Leap', },
        { id: 9, title: 'Acoustic Dreams', artist: 'The Campfire', filePath: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-9.mp3', imagePath: 'https://placehold.co/300x300/f43f5e/ffffff?text=Acoustic+Dreams', },
        { id: 10, title: 'City Pop', artist: 'Night Tempo', filePath: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-10.mp3', imagePath: 'https://placehold.co/300x300/0ea5e9/ffffff?text=City+Pop', },
    ];

    // --- 2. STATE MANAGEMENT ---
    let currentSongIndex = 0;
    let isPlaying = false;
    let isShuffle = false;
    let isRepeat = false;
    let favorites = [];
    let recentlyPlayed = [];
    let audio = new Audio();
    let currentPlaylist = [...songs];

    // --- 3. DOM ELEMENT REFERENCES ---
    const albumArt = document.getElementById('album-art');
    const songTitle = document.getElementById('song-title');
    const songArtist = document.getElementById('song-artist');
    const playPauseBtn = document.getElementById('play-pause-btn');
    const playIcon = document.getElementById('play-icon');
    const pauseIcon = document.getElementById('pause-icon');
    const prevBtn = document.getElementById('prev-btn');
    const nextBtn = document.getElementById('next-btn');
    const seekBar = document.getElementById('seek-bar');
    const volumeBar = document.getElementById('volume-bar');
    const currentTimeEl = document.getElementById('current-time');
    const totalDurationEl = document.getElementById('total-duration');
    const shuffleBtn = document.getElementById('shuffle-btn');
    const repeatBtn = document.getElementById('repeat-btn');
    const playlistContainer = document.getElementById('playlist-container');
    const searchInput = document.getElementById('search-input');
    const voiceSearchBtn = document.getElementById('voice-search-btn');
    const tabAll = document.getElementById('tab-all');
    const tabFavorites = document.getElementById('tab-favorites');
    const tabRecent = document.getElementById('tab-recent');
    const visitorCounter = document.getElementById('visitor-counter');

    // --- 4. CORE PLAYER FUNCTIONS ---
    
    function loadSong(song) {
        songTitle.textContent = song.title;
        songArtist.textContent = song.artist;
        albumArt.src = song.imagePath;
        audio.src = song.filePath;
        updateActivePlaylistItem(song.id);
        document.title = `${song.title} - ${song.artist}`;
    }

    function playSong() {
        isPlaying = true;
        playPauseBtn.classList.add('playing');
        playIcon.classList.add('hidden');
        pauseIcon.classList.remove('hidden');
        albumArt.classList.add('spin-slow');
        audio.play();
        addToRecentlyPlayed(songs[currentSongIndex].id);
    }

    function pauseSong() {
        isPlaying = false;
        playPauseBtn.classList.remove('playing');
        playIcon.classList.remove('hidden');
        pauseIcon.classList.add('hidden');
        albumArt.classList.remove('spin-slow');
        audio.pause();
    }

    function togglePlayPause() {
        if (isPlaying) {
            pauseSong();
        } else {
            playSong();
        }
    }
    
    function nextSong() {
        if (isShuffle) {
            let randomIndex;
            do {
                randomIndex = Math.floor(Math.random() * currentPlaylist.length);
            } while (randomIndex === currentSongIndex && currentPlaylist.length > 1);
            currentSongIndex = randomIndex;
        } else {
            currentSongIndex = (currentSongIndex + 1) % currentPlaylist.length;
        }
        loadSong(currentPlaylist[currentSongIndex]);
        playSong();
    }

    function prevSong() {
        currentSongIndex = (currentSongIndex - 1 + currentPlaylist.length) % currentPlaylist.length;
        loadSong(currentPlaylist[currentSongIndex]);
        playSong();
    }
    
    // --- 5. UI & PLAYLIST FUNCTIONS ---
    
    function renderPlaylist(playlistToRender) {
        playlistContainer.innerHTML = '';
        if (playlistToRender.length === 0) {
             playlistContainer.innerHTML = `<p class="text-center text-gray-500 mt-4">No songs found.</p>`;
             return;
        }
        playlistToRender.forEach((song, index) => {
            const isFavorite = favorites.includes(song.id);
            const songEl = document.createElement('div');
            songEl.className = 'playlist-item flex items-center p-2 rounded-lg cursor-pointer hover:bg-gray-700/50 transition';
            songEl.dataset.id = song.id;
            
            songEl.innerHTML = `
                <img src="${song.imagePath}" alt="${song.title}" class="w-12 h-12 rounded-md mr-4 object-cover">
                <div class="flex-1">
                    <p class="font-semibold text-white">${song.title}</p>
                    <p class="text-sm text-gray-400">${song.artist}</p>
                </div>
                <button class="favorite-btn p-2 rounded-full hover:bg-gray-600 transition" data-song-id="${song.id}">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="${isFavorite ? '#ef4444' : 'none'}" stroke="${isFavorite ? '#ef4444' : 'currentColor'}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path>
                    </svg>
                </button>
            `;

            // Play song on click (but not on favorite button)
            songEl.addEventListener('click', (e) => {
                if (!e.target.closest('.favorite-btn')) {
                    currentPlaylist = playlistToRender;
                    currentSongIndex = index;
                    loadSong(currentPlaylist[currentSongIndex]);
                    playSong();
                }
            });

            // Favorite button functionality
            songEl.querySelector('.favorite-btn').addEventListener('click', (e) => {
                e.stopPropagation();
                toggleFavorite(song.id);
            });

            playlistContainer.appendChild(songEl);
        });
        updateActivePlaylistItem(currentPlaylist[currentSongIndex]?.id);
    }

    function updateActivePlaylistItem(songId) {
        document.querySelectorAll('.playlist-item').forEach(item => {
            item.classList.remove('active');
            if (parseInt(item.dataset.id) === songId) {
                item.classList.add('active');
            }
        });
    }
    
    // --- 6. FEATURE IMPLEMENTATIONS ---

    function toggleFavorite(songId) {
        const favIndex = favorites.indexOf(songId);
        if (favIndex > -1) {
            favorites.splice(favIndex, 1);
        } else {
            favorites.push(songId);
        }
        localStorage.setItem('musicPlayerFavorites', JSON.stringify(favorites));
        
        // Re-render current view to show updated favorite status
        const activeTab = document.querySelector('.tab-button.active').id;
        if (activeTab === 'tab-favorites') {
            showFavorites();
        } else {
            renderPlaylist(currentPlaylist);
        }
    }
    
    function addToRecentlyPlayed(songId) {
        // Remove if it exists to move it to the front
        const existingIndex = recentlyPlayed.indexOf(songId);
        if (existingIndex > -1) {
            recentlyPlayed.splice(existingIndex, 1);
        }
        // Add to the beginning
        recentlyPlayed.unshift(songId);
        // Keep the list at a reasonable size (e.g., 15)
        if (recentlyPlayed.length > 15) {
            recentlyPlayed.pop();
        }
        localStorage.setItem('musicPlayerRecentlyPlayed', JSON.stringify(recentlyPlayed));
    }

    function handleSearch() {
        const query = searchInput.value.toLowerCase();
        const filteredSongs = songs.filter(song => 
            song.title.toLowerCase().includes(query) || 
            song.artist.toLowerCase().includes(query)
        );
        renderPlaylist(filteredSongs);
        // If search is cleared, go back to all songs tab
        if (!query) {
            switchTab(tabAll);
            renderPlaylist(songs);
        }
    }

    function handleVoiceSearch() {
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        if (!SpeechRecognition) {
            alert("Sorry, your browser doesn't support voice search.");
            return;
        }
        const recognition = new SpeechRecognition();
        recognition.lang = 'en-US';
        recognition.start();

        voiceSearchBtn.classList.add('text-red-500');

        recognition.onresult = (event) => {
            const transcript = event.results[0][0].transcript;
            searchInput.value = transcript;
            handleSearch();
        };
        
        recognition.onend = () => {
            voiceSearchBtn.classList.remove('text-red-500');
        };

        recognition.onerror = (event) => {
            alert('Error occurred in recognition: ' + event.error);
        };
    }
    
    // --- 7. LOCAL STORAGE & INITIALIZATION ---

    function loadFromLocalStorage() {
        const storedFavorites = localStorage.getItem('musicPlayerFavorites');
        const storedRecent = localStorage.getItem('musicPlayerRecentlyPlayed');
        const storedCount = localStorage.getItem('musicPlayerVisitorCount');

        if (storedFavorites) favorites = JSON.parse(storedFavorites);
        if (storedRecent) recentlyPlayed = JSON.parse(storedRecent);

        // Visitor counter logic
        let count = storedCount ? parseInt(storedCount) : 0;
        count++;
        localStorage.setItem('musicPlayerVisitorCount', count);
        visitorCounter.textContent = `Visitors: ${count}`;
    }
    
    // --- 8. EVENT LISTENERS ---
    
    // Player controls
    playPauseBtn.addEventListener('click', togglePlayPause);
    nextBtn.addEventListener('click', nextSong);
    prevBtn.addEventListener('click', prevSong);
    
    // Audio element events
    audio.addEventListener('timeupdate', () => {
        const { currentTime, duration } = audio;
        const progressPercent = (currentTime / duration) * 100;
        seekBar.value = progressPercent;
        currentTimeEl.textContent = formatTime(currentTime);
    });

    audio.addEventListener('loadedmetadata', () => {
        totalDurationEl.textContent = formatTime(audio.duration);
    });

    audio.addEventListener('ended', () => {
        if (isRepeat) {
            playSong();
        } else {
            nextSong();
        }
    });
    
    // Seek & Volume bars
    seekBar.addEventListener('input', (e) => {
        const seekTime = (audio.duration / 100) * e.target.value;
        audio.currentTime = seekTime;
    });

    volumeBar.addEventListener('input', (e) => {
        audio.volume = e.target.value;
    });
    
    // Optional features
    shuffleBtn.addEventListener('click', () => {
        isShuffle = !isShuffle;
        shuffleBtn.classList.toggle('text-blue-500', isShuffle);
    });

    repeatBtn.addEventListener('click', () => {
        isRepeat = !isRepeat;
        repeatBtn.classList.toggle('text-blue-500', isRepeat);
    });

    // Search
    searchInput.addEventListener('input', handleSearch);
    voiceSearchBtn.addEventListener('click', handleVoiceSearch);

    // Tabs
    function switchTab(activeTab) {
        document.querySelectorAll('.tab-button').forEach(btn => btn.classList.remove('active'));
        activeTab.classList.add('active');
    }

    function showFavorites() {
        const favoriteSongs = songs.filter(song => favorites.includes(song.id));
        renderPlaylist(favoriteSongs);
    }

    function showRecent() {
         const recentSongs = recentlyPlayed.map(id => songs.find(song => song.id === id)).filter(Boolean);
         renderPlaylist(recentSongs);
    }

    tabAll.addEventListener('click', () => {
        switchTab(tabAll);
        renderPlaylist(songs);
        currentPlaylist = [...songs];
    });
    tabFavorites.addEventListener('click', () => {
        switchTab(tabFavorites);
        showFavorites();
    });
    tabRecent.addEventListener('click', () => {
        switchTab(tabRecent);
        showRecent();
    });
    
    // --- UTILITY FUNCTIONS ---
    function formatTime(seconds) {
        const minutes = Math.floor(seconds / 60);
        const secs = Math.floor(seconds % 60);
        return `${minutes}:${secs < 10 ? '0' : ''}${secs}`;
    }

    // --- INITIALIZE APP ---
    function init() {
        loadFromLocalStorage();
        loadSong(songs[currentSongIndex]);
        renderPlaylist(songs);
    }

    init();
});
